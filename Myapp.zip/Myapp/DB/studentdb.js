let student=[
				{regno:'2021/ICT/79',name:'Wijekoon',age:25,course:'IT',gender:"female"},
				{regno:'2021/ICT/40',name:'Ariyawansa',age:26,course:'IT',gender:"female"},
				{regno:'2021/ICT/22',name:'Kadigamuwa',age:23,course:'IT',gender:"male"},
				{regno:'2021/ICT/31',name:'Nawarathna',age:25,course:'IT',gender:"female"},
				{regno:'2021/ICT/81',name:'ushani',age:25,course:'BIO',gender:"female"}
				];
				
module.exports=student;