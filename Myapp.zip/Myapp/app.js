const express = require('express');
const app =express();
const port=3001;
let students=[
				{regno:'2021ICT79',name:'Wijekoon',age:25,course:'IT',gender:"female"},
				{regno:'2021ICT40',name:'Ariyawansa',age:26,course:'IT',gender:"male"},
				{regno:'2021ICT22',name:'Kadigamuwa',age:23,course:'IT',gender:"female"}
				];
//01
app.get('/',(req,res)=>{
    res.send(students);
});	*/
//02
app.get('/msg',(req,res)=>{
	res.send("Hello");
});*/
//03.display the details of the mentioned registration number.
app.get('/stu/:id',(req,res)=>{
	const id = req.params.id
	const result = students.find(student => student.regno === id);
	if(result){
		res.send(result);
	}else{
		res.status(404).send("student not found");
	}
});*/

//04 filter student by name.
app.get('/name/:name',(req,res)=>{
    const name = req.params.name
    const result = students.filter(student=>student.name === name);
    res.send(result);
});
//05. filter student by gender
app.get('/gender/:gender',(req,res)=>{
    const gender = req.params.gender
    const result = students.filter(student=>student.gender === gender);
    res.send(result);
});

//06 student file export
const students = require('./DB/studentdb')

app.get('/',(req,res)=>{
    res.send(students);
});
app.listen(port,()=>{
    console.log(`Server is running on:${port}`);
});